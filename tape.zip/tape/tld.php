<!DOCTYPE html>
<html>
<head>
<title>TLD</title>
		
<?php
	include 'koneksi.php';
	error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<link rel="stylesheet" href="style.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">

body 
			
	{
		background-color: white;
		font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
	}
.demo-table 
	{
		border-collapse: collapse;
		font-size: 13px;
	}
.demo-table th,	.demo-table td 
	{
		border: 1px solid #e1edff;
		padding: 7px 17px;
	}
.demo-table .title 
	{
		caption-side: bottom;
		margin-top: 12px;
	}
.demo-table th 
	{
		background-color: #508abb;
		color: #FFFFFF;
		border-color: #6ea1cc !important;
		text-transform: uppercase;
	}
.demo-table td 
	{
		color: #353535;
	}
.demo-table  td:first-child, .demo-table  td:last-child, .demo-table  td:nth-child(4) 
	{
		text-align: left;
	}
.demo-table  tr:nth-child(odd) td 
	{
		background-color: #f4fbff;
	}
.demo-table  tr:hover td 
	{
		background-color: #ffffa2;
		border-color: #ffff0f;
		transition: all .2s;
	}
h3
	{
		font-family: sans-serif;
	}
.dropbtn 
	{
		background-color: #5bc0de;
		color: white;
		padding: 3px;
		font-size: 12px;
		border: none;
	}
.dropdown 
	{
		position: relative;
		display: inline-block;
	}
.dropdown-content 
	{
		display: none;
		position: absolute;
		background-color: lightgrey;
		min-width: 200px;
		z-index: 1;
	}
.dropdown-content a 
	{
		color: black;
		padding: 12px 16px;
		text-decoration: none;
		display: block;
	}
.dropdown-content a:hover {background-color: white;}
.dropdown:hover .dropdown-content {display: block;}
.dropdown:hover .dropbtn {background-color: grey;}
</style>
</head>
<center>
<body>
	<div class="header">
		<img src="kpc.png" width="180px" height="75px" align="left">
		<table border="0" width="100%">
			<tr>
				<td width="85%" align="center">
					<font face="Britannic Bold" color="#CD5C5C" size="6">Data TLD</font>
				</td>
			</tr>
		</table>
	</div>

	<div class="wrap">
		<table border="0" width="30%">
			<tr>
				<td>
					<div class="dropdown">
						<button class="btn btn-primary btn-xs"> MENU </button>
						<div class="dropdown-content">
							<a href="index.php">Tape</a>
							<a href="tld.php">TLD</a>
							<a href="volumepool.php">Volume Pool</a>
							<a href="location.php">Location</a>
							<a href="media.php">Media Status</a>
						</div>
					</div>
					<button class="btn btn-info btn-xs" data-toggle="modal" data-target="#modalFormtld">
							<i class='fas fa-plus-circle' style='font-size:12px;color:white'></i> Add
					</button>				
				</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
		</table>

		<table border="1" width="30%" class="demo-table">
			<tr>
				<th width="1%">No</th>
				<th width="28%">TLD</th>
				<th width="1%">Action</th>
			</tr>

			<?php 
				
				$q="select * from tld";
				$master = mysqli_query($koneksi,$q);
				$no = 1;
				foreach ($master as $row) 
				{
					echo 
					"<tr>
						<td>$no</td>
						<td>".$row['tld_list']."</td>
						<td>
							<a href='deletetld.php?tld_list=$row[tld_list]' class='btn btn-danger btn-xs'>Del</a>
						</td>
					</tr>";
					$no++;
				}
			?>
		</table>
	</div>

	<form method="POST" action="tld.php">
		<div class="modal fade" id="modalFormtld" role="dialog">
			<div class="modal-dialog">
			    <div class="modal-content">
			        <!-- Modal Header -->
			        <div class="modal-header">
			            <button type="button" class="close" data-dismiss="modal">
			                <span aria-hidden="true">&times;</span>
			                <span class="sr-only">Close</span>
			            </button>
			            <h4 class="modal-title" id="labelModalKu">Add Form</h4>
			        </div>

			        <!-- Modal Body -->
			        <div class="modal-body">
			            <p class="statusMsg"></p>
			            <div class="form-group">
			                <label>TLD</label>
			                <input type="text" class="form-control" name="masukkantld" placeholder="Insert TLD"/>
			            </div>
			        <!-- Modal Footer -->
			        <div class="modal-footer">
			            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			            <button type="submit" class="btn btn-primary submitBtn">Save</button>
			        </div>
			  </div>
			</div>
  		</div>

		<?php
			$tld 		= $_POST['masukkantld'];
			if(isset($tld))
				{
					$q = mysqli_query($koneksi,"insert into tld set tld_list='$tld'");
					if($q==1)
						{
						    echo"<script language='javascript'>alert('Input Success');
						          document.location='tld.php'</script>";
						}
				    else
						{
						    echo"<script language='javascript'>alert('ID is Available');
						          document.location='tld.php'</script>";
						}
					          
				}
		?>
	</form>

</body>
</center>
</html>
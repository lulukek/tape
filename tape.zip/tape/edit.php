<!DOCTYPE html>
<html>
<head>
		<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
		<div class="header">
			<img src="kpc.png" width="180px" height="75px" align="left">
			<table border="0" width="100%">
				<tr>
					<td width="85%" align="center">
						<font face="Britannic Bold" color="#CD5C5C" size="5">Form Edit Tape Data</font>
					</td>
				</tr>
			</table>
		</div>

		<div class="wrap">
			<legend align="center"></legend>
				<form method="POST" action="edit.php">
					 <div class="kotak_login">
						 	<?php
						 		include 'koneksi.php';
						 		error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
							    $id = $_GET['id_tape'];
								$query = mysqli_query($koneksi,"SELECT * FROM tape_list WHERE id_tape = '$id'")or die(mysql_error());
								$row = mysqli_fetch_array($query)	
							?>

							<label>ID Tape</label> 
							<input type="text" name="id"  value="<?php echo $row['id_tape'] ?>" readonly="readonly" class="form_login">
					 
							<label>TLD</label>
								<select name='tld' value="<?php echo $row['tld'] ?>" class="form_login"/>
									<?php
										$a=mysqli_query($koneksi,"select * from tld");
										    while($b=mysqli_fetch_array($a))
										        {
											          if($b[0]==$row[1])
											            echo"<option value='$b[0]' selected>$b[0]</option>";
											          else
											            echo"<option value='$b[0]'>$b[0]</option>";
										        }
										?>
								</select>
								
							<label>Data Expiration</label>
							<input type="date" name="exp" value="<?php echo $row['data_expiration'] ?>" class="form_login"/ >

							<label>Volume Pool</label>
								<select name='vol' value="<?php echo $row['vol'] ?>" class="form_login"/>
									<?php
										$a1=mysqli_query($koneksi,"select * from vol_pool");
										    while($b1=mysqli_fetch_array($a1))
										        {
											          if($b1[0]==$row[3])
											             echo"<option value='$b1[0]' selected>$b1[0]</option>";
											          else
											             echo"<option value='$b1[0]'>$b1[0]</option>";
										        }
									?>
								</select>

							<label>Location</label>
								<select name='loc' value="<?php echo $row['loc'] ?>" class="form_login"/>
									<?php
										$a2=mysqli_query($koneksi,"select * from location");
										    while($b2=mysqli_fetch_array($a2))
										        {
											          if($b2[0]==$row[4])
											             echo"<option value='$b2[0]' selected>$b2[0]</option>";
											          else
											             echo"<option value='$b2[0]'>$b2[0]</option>";
										        }
									?>
								</select>

							<label>Remarks</label>
							<input type="text" name="remarks" value="<?php echo $row['remarks'] ?>" class="form_login"/>

							<label>Date Of Change</label>
							<input type="date" name="change"  value="<?php echo $row['date_of_change'] ?>" class="form_login"/>

							<label>Media Status</label>
								<select name='media' value="<?php echo $row['media_list'] ?>" class="form_login"/>
									<?php
										$a3=mysqli_query($koneksi,"select * from media_status");
										    while($b3=mysqli_fetch_array($a3))
										        {
											           if($b3[0]==$row[6])
											             echo"<option value='$b3[0]' selected>$b3[0]</option>";
											           else
											             echo"<option value='$b3[0]'>$b3[0]</option>";
										        }
									?>
								</select>
					 
							<input type="submit" class="tombol_login" value="SAVE">
					</div>
				 
		   			<?php
					    $id = $_POST['id'];
					    $tld = $_POST['tld'];
					    $exp = $_POST['exp'];
					    $vol = $_POST['vol'];
					    $loc = $_POST['loc'];
					    $remarks = $_POST['remarks'];
					    $media = $_POST['media'];
					    $change = $_POST['change'];
					    if(isset($id))
					    {
					        $q = mysqli_query($koneksi,"update tape_list set tld='$tld', data_expiration='$exp', volume_pool='$vol', location='$loc', remarks='$remarks', media_status='$media', date_of_change='$change' where id_tape='$id'");
						        if($q==1)
						        {
							          echo"<script language='javascript'>alert('Edit Success');
							          document.location='index.php'</script>";
						        }
						        else
						        {
							          echo"<script language='javascript'>alert('Edit Failed');
							          document.location='edit.php'</script>";
						        }
					          
					    }
					?>
				</form>
		</div>
</body>
</html>


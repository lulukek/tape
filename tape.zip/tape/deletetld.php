<?php
include 'koneksi.php';
$id = $_GET['tld_list'];
$q=mysqli_query($koneksi, "delete from tld where tld_list = '$id'");
	if($q==1)
		{
			echo"<script language='javascript'>alert('Delete Success');
			document.location='tld.php'</script>";
		}
	else
		{
			echo"<script language='javascript'>alert('Delete Failed');
			document.location='tld.php'</script>";
		}
<?php
include 'koneksi.php';
$id = $_GET['loc'];
$q=mysqli_query($koneksi, "delete from location where loc = '$id'");
	if($q==1)
		{
			echo"<script language='javascript'>alert('Delete Success');
			document.location='location.php'</script>";
		}
	else
		{
			echo"<script language='javascript'>alert('Delete Failed');
			document.location='location.php'</script>";
		}
<?php
include 'koneksi.php';
$id = $_GET['media_list'];
$q=mysqli_query($koneksi, "delete from media_status where media_list = '$id'");
	if($q==1)
		{
			echo"<script language='javascript'>alert('Delete Success');
			document.location='media.php'</script>";
		}
	else
		{
			echo"<script language='javascript'>alert('Delete Failed');
			document.location='media.php'</script>";
		}
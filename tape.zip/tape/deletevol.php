<?php
include 'koneksi.php';
$id = $_GET['vol'];
$q=mysqli_query($koneksi, "delete from vol_pool where vol = '$id'");
	if($q==1)
		{
			echo"<script language='javascript'>alert('Delete Success');
			document.location='volumepool.php'</script>";
		}
	else
		{
			echo"<script language='javascript'>alert('Delete Failed');
			document.location='volumepool.php'</script>";
		}